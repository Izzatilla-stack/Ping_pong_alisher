Snake
=====

Snake, classic arcade game.

.. literalinclude:: ../freegames/snake.py
