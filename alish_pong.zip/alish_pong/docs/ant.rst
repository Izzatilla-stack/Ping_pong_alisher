Ant
===

Ant, simple animation demo.

.. literalinclude:: ../freegames/ant.py
