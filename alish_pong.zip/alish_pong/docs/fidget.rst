Fidget
======

Fidget, inspired by fidget spinners.

.. literalinclude:: ../freegames/fidget.py
