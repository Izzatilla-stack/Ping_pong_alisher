Maze
====

Maze, move from one side to another.

.. literalinclude:: ../freegames/maze.py
